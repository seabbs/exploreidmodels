library(testthat)
library(biddmodellingcourse)

test_check("biddmodellingcourse")
