
expect_fixed_output <- function(object, output) {
  expect_output(object, output, fixed = TRUE)
}
