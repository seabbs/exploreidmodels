#' Pretty Figure Reference
#'
#' Imported from [prettypublisher](https://www.samabbott.co.uk/prettypublisher/).
#'
#' @name pretty_figref
#' @keywords internal
#' @export
#' @importFrom prettypublisher pretty_figref
#' @inherit prettypublisher::pretty_figref
#' @example 
#' 
NULL