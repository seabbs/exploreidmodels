
context("shinyWidgetsGallery")


test_that("Default", {

  library("shiny")
  source(file = system.file('examples/shinyWidgets/global.R', package='shinyWidgets'))
  source(file = system.file('examples/shinyWidgets/ui.R', package='shinyWidgets'))

})
