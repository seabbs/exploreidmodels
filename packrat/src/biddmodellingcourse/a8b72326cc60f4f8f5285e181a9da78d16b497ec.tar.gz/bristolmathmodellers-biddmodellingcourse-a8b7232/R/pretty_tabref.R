#' Pretty Table Reference
#'
#' Imported from [prettypublisher](https://www.samabbott.co.uk/prettypublisher/).
#'
#' @name pretty_tabref
#' @keywords internal
#' @export
#' @importFrom prettypublisher pretty_tabref
#' @inherit prettypublisher::pretty_tabref
#' @example 
#' 
NULL